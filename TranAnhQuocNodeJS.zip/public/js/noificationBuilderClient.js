$(function() {
    $("#sendNotiMsg").click(function() {
        var message = $("#textMessage").text()

        if (message !== "") {

        }
    })
})