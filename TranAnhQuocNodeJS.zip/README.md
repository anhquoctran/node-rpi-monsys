# Raspberry Pi Monitor and Controller System

A simple monitor system for Raspberry Pi

![Hello from Pi! Cheers!](public/images/raspberry-pi-header.png)<br>
#### Screenshot
![Screenshot 1](public/images/screenshot.png)
