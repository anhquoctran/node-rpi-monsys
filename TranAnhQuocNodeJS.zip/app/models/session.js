module.exports = {
    name: String,
    key: String,
    token: String,
    datetime: Date,
    client: String,
    mac: String,
    path: String
}